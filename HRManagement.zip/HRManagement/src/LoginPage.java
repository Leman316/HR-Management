

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.LoginDB;

/**
 * Servlet implementation class LoginPage
 */
@WebServlet("/LoginPage")
public class LoginPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginPage() {
        super();
        // TODO Auto-generated constructor stub
    }
    public void service(HttpServletRequest req, HttpServletResponse response) throws IOException {
    	
    	LoginDB ldb= new LoginDB();
    	//ldb.check("admin","12345");
    	String uname=req.getParameter("username");
    	String pass=req.getParameter("password");
    	boolean f=true;
    	if(uname.isEmpty() || pass.isEmpty())f=false;
    	if (ldb.check(uname,pass) && f) {
    		
    		HttpSession session=req.getSession();  
            session.setAttribute("uname",uname);
            response.sendRedirect("index2.html");
            
    	}else
    	{
    		PrintWriter out= response.getWriter();
    	response.setContentType("text/html");
    	out.println("<!DOCTYPE html>\r\n<html>\r\n<head>\r\n	<meta charset=\"utf-8\">\r\n	<title>Login</title>\r\n		\r\n<link href=\"https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i\" rel=\"stylesheet\"> \r\n" + 
    			"		<link rel=\"stylesheet\" type=\"text/css\" href=\"css/l-style.css\">\r\n	</head>");
    	
    	out.println("<body>\r\n\r\n	<div class=\"container\">\r\n		\r\n" + 
    			"			<div class=\"login-form\">\r\n		<h3 class=\"heading\"> Login </h3>\r\n		<br></br>\r\n\r\n" + 
    			"				<form action='login'>\r\n\r\n" + "<font color="+"red"+">"+"Login Not Successful"+"</font>\r\n	<input type=\"text\" name=\"username\" placeholder=\"Username\">\r\n" + 
    			"				<input type=\"Password\" name=\"password\" placeholder=\"Password\">\r\n<input type=\"submit\" value=\"Login\" >\r\n" + 
    			"				</form>\r\n	<br>\r\n<form action='registration' method=\"get\">\r\n	<p class=\"text-white\"> Don't have account? <a href=\"Registration.html\">Click Here</a></p>\r\n</form>\r\n" + 
    			"\r\n			</div>\r\n\r\n\r\n</div>\r\n\r\n</body>\r\n</html>");

    	}
    	  
    	
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doGet(req, response);
	}

}
