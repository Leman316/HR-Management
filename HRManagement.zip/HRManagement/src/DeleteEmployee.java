

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.Delete;
import database.Search;

/**
 * Servlet implementation class DeleteEmployee
 */
@WebServlet("/DeleteEmployee")
public class DeleteEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteEmployee() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void service(HttpServletRequest req, HttpServletResponse response) throws IOException {
    	Delete d=new Delete();
    	PrintWriter out= response.getWriter();
    	response.setContentType("text/html");
    	int id=Integer.parseInt(req.getParameter("id"));
    	out.println("<!doctype html><html lang=\"en\"><head><title>HR Management</title><!-- Required meta tags --><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\"><!-- Bootstrap CSS --><link rel=\"stylesheet\" type=\"text/css\" href=\"css/bootstrap.min.css\"><!-- Theme CSS file --><link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\"><!-- Google Fonts Roboto --><link href=\"https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i\" rel=\"stylesheet\"> <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script><script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script></head>\r\n" + 
    			"");
    	
    	out.println("<body><!-- Navigation Menu --><section><nav class=\"navbar navbar-default\"><div class=\"container\"><!-- Brand and toggle get grouped for better mobile display --><div class=\"navbar-header\"><button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\"><span class=\"sr-only\">Toggle navigation</span><span class=\"icon-bar\"></span><span class=\"icon-bar\"></span><span class=\"icon-bar\"></span></button><a class=\"navbar-brand\" href=\"#\"><img src=\"images/logo.png\" class=\"log\"></a> </div><!-- Collect the nav links, forms, and other content for toggling --><div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\"><ul class=\"nav navbar-nav navbar-right\"><li><a href=\"index2.html\">Home </a></li><li class=\"dropdown\"><a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">Employee <span class=\"caret\"></span></a><ul class=\"dropdown-menu\"><li><a href=\"AddEmp.html\">Add Employee</a</li><li><a href=\"SearchEmp.html\">Search Employee</a></li><li><a href=\"#\">Remove Employee</a></li> </ul></li><li><a href=\"Login2.html\">Login</a></li></ul></div><!-- /.navbar-collapse --></div><!-- /.container-fluid --></nav></section>");
    	System.out.println(id);
    	String name=d.delete(id);
    	if (name.isEmpty())
    		out.print("Not Found");
    	else out.println(name);
    	
    	out.println("<section class=\"footer\"><div class= \"container\"><div class=\"row\"></div></div></section><!-- jQuery first, then Popper.js, then Bootstrap JS --><script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script><script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js\" integrity=\"sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh\" crossorigin=\"anonymous\"></script><script type=\"text/javascript\" src=\"js/bootstrap.min.js\"></script></body></html>");
    	
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
