package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.jdbc.PreparedStatement;

public class AddEmployee {
	public boolean Check(int id,String uname,String mobile,String email,String post,String dept,String address) {
		String sql="Insert into admin(Name,Mobile,Email,Username,Pass) values(?,?,?,?,?)";
		String url="jdbc:mysql://localhost:3306/hr_management";
		//System.out.println("sss");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url,"root","");
			PreparedStatement st = (PreparedStatement) conn.prepareStatement(sql);
			
			
			
		st.executeUpdate("Insert into Employee values('"+id+"','"+uname+"','"+mobile+"','"+ email+"','"+post+"','"+ dept+"','"+address+"')");
			
			System.out.println(uname);
			//System.out.println(password);
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}

}
