package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.jdbc.PreparedStatement;

public class Delete {
	
		
		public String delete(int id) {

			String name="";
			
			String sql="Delete from employee where Id=?";
			String url="jdbc:mysql://localhost:3306/hr_management";
			//System.out.println("sss");
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection conn=DriverManager.getConnection(url,"root","");
				PreparedStatement st = (PreparedStatement) conn.prepareStatement(sql);

			
				st.setInt(1, id);
				boolean f=false;
				int rs=st.executeUpdate();
				
				
				 name="Deleted";
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			return name;
		}
	}

