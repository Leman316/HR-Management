package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.jdbc.PreparedStatement;

public class Search {
	
	public String[] search(int id) {

		String name="";
		String mobile="";
		String email="";
		String dept="";
		String address="";
		String position="";
		
		String sql="Select * from employee where Id=?";
		String url="jdbc:mysql://localhost:3306/hr_management";
		//System.out.println("sss");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url,"root","");
			PreparedStatement st = (PreparedStatement) conn.prepareStatement(sql);

		
			st.setInt(1, id);
		
			ResultSet rs=st.executeQuery();
			
			while (rs.next())
			{
				
			   name= rs.getString("Name");
			   mobile=rs.getString("Mobile");
			   email=rs.getString("Email");
			   dept=rs.getString("Department");
			   address=rs.getString("Position");
			   position=rs.getString("Address");
			   System.out.println(mobile);
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		String[] s= {name,mobile,email,position,dept,address};
		return s;
	}

}
