package database;

import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.jdbc.PreparedStatement;

import java.sql.Connection;


public class LoginDB {
	
	public boolean check(String uname,String password) {
		String sql="select * from admin where Username=? and password=?";
		String url="jdbc:mysql://localhost:3306/hr_management";
		//System.out.println("sss");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url,"root","");
			PreparedStatement st = (PreparedStatement) conn.prepareStatement(sql);
			//System.out.println("sss");
			st.setString(1, uname);
			st.setString(2, password);
			ResultSet rs=
					st.executeQuery("select * from admin where Username='"+uname +"'and pass= '"+ password+"'");
			
			System.out.println(uname);
			System.out.println(password);
			if (rs.next()) {
				System.out.println("dsds");
				return true;
			
			}
			else
				System.out.println("fasfsf");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}

}
