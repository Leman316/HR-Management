package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.jdbc.PreparedStatement;

public class New_Registration {
	
	public boolean check(String uname,String email,String password,String conpassword,String mobile) {
		String sql="Insert into admin(Name,Mobile,Email,Username,Pass) values(?,?,?,?,?)";
		String url="jdbc:mysql://localhost:3306/hr_management";
		//System.out.println("sss");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url,"root","");
			PreparedStatement st = (PreparedStatement) conn.prepareStatement(sql);
			ResultSet rs=st.executeQuery("Select count(*) from admin");
			int id=0;
			
			while (rs.next())
			{
			   id= rs.getInt(1);
			   
			}
			
			System.out.println(id);
			st.setString(1, uname);
			st.setString(2, email);
			st.setString(3, password);
			st.setString(4, conpassword);
			st.setString(5, mobile);
			System.out.println(mobile);
			
					st.executeUpdate("Insert into admin(Id,Name,Mobile,Email,Username,Pass) values('"+id+"','"+uname+"','"+mobile+"','"+ email+"','"+password+"','"+ conpassword+"')");
			
			System.out.println(uname);
			System.out.println(password);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}

}
